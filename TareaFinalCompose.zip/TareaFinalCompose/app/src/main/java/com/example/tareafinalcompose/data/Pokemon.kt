package com.example.tareafinalcompose.data

data class Pokemon(
    val name: String,
    val url: String
)
