package com.example.tareafinalcompose.data

data class PokeApiResponse(
    val results: List<Pokemon>
)
